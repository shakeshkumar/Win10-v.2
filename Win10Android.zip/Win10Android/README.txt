HOW TO BUILD (needs a PC with free Android Studio)
1. Unzip this folder. Open Android Studio > Open > select Win10Android.
2. Wait for "Gradle sync" to finish (needs internet).
3. Plug in your phone (USB debugging ON) and press Run,
   or Build > Build APK(s), then copy app-debug.apk to the phone and install it.
Search in the Chrome app now opens sites in a real in-app browser (no phone browser).
